<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Facebook Video Downloader</title>
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
</head>

<div class="navs">
  <div class="hgrd">
    <h1>FB<strong>DOWNLOAD</strong></h1>
  </div>
</div>

<div class="container">
  <div class="row">
    <div class="col-sm-12">
      <div class="redef-center vid">
        <div class="sny">
          <h2>Cole o link do video aqui</h2>
          <div class="input-group col-mg-12">
              <input type="text" name="url" class="form-control" placeholder="Cole o link do video aqui" id="url">
              <span class="input-group-btn"><a class="btn btn-primary" onclick="getDownloadLink();" id="download">Download!</a></span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-sm-12" id="result" style="display:none;">
        <div id="bar">
          <p class="text-center">
            <img src="img/ajax.gif">
          </p>
        </div>
        <div id="downloadUrl" style="display:none;">
        
        <div class="redef-center">
          <div class="row">            
            <div class="col-sm-6">
                <video width="100%" id="vids" controls controlsList="nodownload nofullscreen">                
                   Your browser does not support the video tag.
                </video>
            </div>            

            <div class="col-sm-6">
                <h4 class="text-left">Informações</h4>
                <p class="text-left">
                  <strong>Titulo: </strong>
                  <span id="title"></span>
                </p>
                <p class="text-left">
                  <strong>Source: </strong>
                  <span id="src"></span>
                </p>
                <hr>
                <h4 class="text-left">Download</h4>
                <p class="text-center" id="sd"></p>
                <p class="text-center" id="hd"></p>
            </div>
          </div>
        </div>

        </div>
      </div>
    </div>
  </div>
</div>

<br><br><br><br><br>

<script type="text/javascript" src="js/jquery.min.js" ></script>
<script type="text/javascript" src="js/bootstrap.min.js" ></script>
<script type="text/javascript">


function getDownloadLink(){
  var vid_url = $("#url").val();

  $("#download").html("Grabbing Link ...");
  $("#download").attr("disabled","disabled");
  $("#result").css("display","block");
  $("#downloadUrl").css("display","none");
  $("#bar").css("display","block");
  $("#hd").html('');
  $("#sd").html('');
  $.ajax({
    type:"POST",
    dataType:'json',
    url:'main.php',
    data:{url:vid_url},
    success:function(data){
      console.log(data);
      $("#bar").css("display","none");
      $("#downloadUrl").css("display","block");
      if(data.type=="success") {

        var img_link = $("#url").val().split("/")[5];
        $("#title").html(data.title);
        $("#img").html('<img width"100%" class="img-sse" src="https://graph.facebook.com/'+img_link+'/picture">');
        $("#src").html('<a id="vid_url" href="'+vid_url+'">'+vid_url+'</a>');
        $("#sd").html('<a class="btn btn-sm btn-success" href="'+data.sd_download_url+'" download="sd.mp4">Baixar baixa qualidade</a>');
        

        if(data.hd_download_url){
        $("#hd").html('<a class="btn btn-sm btn-success" href="'+data.hd_download_url+'" download="hd.mp4">Baixar alta qualidade</a>');
        $("#vids").html('<source src="'+data.hd_download_url+'" type="video/mp4">');
        }
      }

      if(data.type=="failure"){
        $("#downloadUrl").html('<h3>'+data.message+'</h3>');
      }

      $("#download").html("Download!");
      $("#download").removeAttr("disabled");
    }
  })
}

</script>
</body>
</html>